﻿using AutoMapper;
using LMS.Data_Access_Layer;
using LMS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LMS.Helpers
{
    //public class AppMapper:Profile
    //{
    //    public AppMapper()
    //    {
    //        CreateMap<LMS_DbContext,Employees>().ReverseMap();
    //    }
        
    //}
}
